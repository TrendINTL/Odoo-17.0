In partner view, there is a new action called "Add to mailing list". This
action open a pop-up to select a mailing list. Selected partners will be added
as mailing list contacts.
