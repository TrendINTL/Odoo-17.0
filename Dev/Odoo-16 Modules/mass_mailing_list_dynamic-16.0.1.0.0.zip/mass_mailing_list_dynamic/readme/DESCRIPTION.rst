Without this addon you have to choose between providing a dynamic domain and
letting your mass mailings reach all partners that match it.

This addon allows you to create dynamic mailing lists, so you can now benefit
from both things.
