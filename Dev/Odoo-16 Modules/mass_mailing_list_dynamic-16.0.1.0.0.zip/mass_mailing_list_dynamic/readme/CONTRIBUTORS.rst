* `Tecnativa <https://www.tecnativa.com>`_:

  * Jairo Llopis
  * Pedro M. Baeza
  * David Vidal
  * Victor M.M. Torres
  * Víctor Martínez

* `Hibou Corp. <https://hibou.io>`_:

  * Jared Kipe <jared@hibou.io>

* `Dynapps N.V. <https://www.dynapps.be>`_:

  * Xander De Jaegere

* `Trobz <https://trobz.com>`_:

    * Nguyễn Minh Chiến <chien@trobz.com>
