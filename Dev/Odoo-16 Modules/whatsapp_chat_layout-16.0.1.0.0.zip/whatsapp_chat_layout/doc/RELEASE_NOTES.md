## Module <whatsapp_chat_layout>

#### 22.03.2023
#### Version 16.0.1.0.0
#### ADD
- Initial commit for Whatsapp Chat Layout in Odoo Discuss