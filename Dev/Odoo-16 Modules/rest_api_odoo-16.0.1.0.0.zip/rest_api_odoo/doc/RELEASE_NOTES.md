## Module <rest_api_odoo>

#### 28.12.2023
#### Version 16.0.1.0.0
 - Initial Commit for Odoo REST API
