## Module <invoice_stock_move>

#### 23.12.2021
#### Version 16.0.1.0.0
#### ADD

Initial Commit
