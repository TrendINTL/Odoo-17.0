ADVANCED CASH FLOW STATEMENTS 16
================================
Generate 4 levels of Dynamic Cash Flow Statements Report.

Configuration
=============

No additional configurations needed

Credits
=======
Developer: Varsha Vivek K @ cybrosys, Contact: odoo@cybrosys.com
    - V14 : Muhammed Nafih @cybrosys
    - V15 : Robin K @cybrosys
     V16 : Robin K @cybrosys
