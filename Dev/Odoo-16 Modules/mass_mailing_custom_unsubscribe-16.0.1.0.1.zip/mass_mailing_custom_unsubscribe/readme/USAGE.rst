Once configured:

#. Go to *Email Marketing > Mailings > Create*.
#. Edit your mass mailing at wish, but remember to add a snippet from
   *Footers*, so people have an *Unsubscribe* link.
#. Send it.
#. If somebody gets unsubscribed, you will see logs about that under
   *Email Marketing > Unsubscriptions*.
