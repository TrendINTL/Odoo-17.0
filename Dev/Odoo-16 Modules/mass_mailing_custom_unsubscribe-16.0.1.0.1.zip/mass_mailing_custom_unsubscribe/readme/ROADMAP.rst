* This module replaces AJAX submission core implementation from the mailing
  list management form, because it is impossible to extend it. When this is
  fixed, this addon will need a refactoring (mostly removing
  duplicated functionality and depending on it instead of replacing it).
