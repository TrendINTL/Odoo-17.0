This addon extends the unsubscription form to let you:

- Choose which mailing lists are not cross-unsubscriptable when unsubscribing
  from a different one.
- Know why and when a contact has been subscribed or unsubscribed from a
  mass mailing.
- Provide proof on why you are sending mass mailings to a given contact, as
  required by the GDPR in Europe.
- Handle discrete unsubscriptions from other recipients that are not a mailing
  list. On standard module, unsubscriptions from these recipients directly
  include that mail on the general blacklist.
