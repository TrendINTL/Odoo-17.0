Payment Approval v15
====================
Enables to use the approval feature in customer and vendor payments.

Installation
============
No additional files neeeded.

Configuration
=============

No configurations needed.

Credits
=======
Developer: v13.0 Mashood K U @ cybrosys, odoo@cybrosys.com
           v14.0 Minhaj T @ cybrosys, odoo@cybrosys.com
           v15.0 Mohammed Shahil M P T @ cybrosys, odoo@cybrosys.com
           v16.0 Neenu Merlin Jose @ cybrosys, odoo@cybrosys.com
