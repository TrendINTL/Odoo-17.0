=================================
Auto Assign Task
=================================
This application is used for assigning the task New and Done as the assign level. so that manager can get fixed assignees for the task level new and done.
