## Module <invoice_format_editor>

#### 31.07.2023
#### Version 16.0.1.0.0
#### ADD
- Initial commit for Invoice Format Editor

#### 03.04.2024
#### Version 16.0.2.1.0
##### UPDATE
- Bug Fix-Resolved the attribute error, updated the report templates
