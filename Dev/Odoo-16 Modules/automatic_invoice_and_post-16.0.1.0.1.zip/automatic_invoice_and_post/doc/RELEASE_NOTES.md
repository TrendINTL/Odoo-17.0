## Module <automatic_invoice_and_post>

#### 24.02.2023
#### Version 16.0.1.0.0
##### ADD
- Initial commit for Automatic Invoice And Post

#### 19.02.2024
#### Version 16.0.1.0.1
##### UPDT
- Bug Fix-Resolved the error while generating back order.


